WGET_ARGS=( https://download.kde.org/stable/plasma/5.21.5/ -A '*.tar.xz' )
