WGET_ARGS=( http://download.kde.org/stable/release-service/21.04.0/src -A '*.tar.xz' )
