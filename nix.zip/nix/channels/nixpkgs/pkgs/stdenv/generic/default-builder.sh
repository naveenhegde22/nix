source $stdenv/setup
genericBuild
