#! /bin/sh

java-zxing com.google.zxing.client.j2se.CommandLineEncoder "$@"
