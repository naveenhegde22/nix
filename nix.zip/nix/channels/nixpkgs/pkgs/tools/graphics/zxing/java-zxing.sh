#! /bin/sh

@jre@/bin/java -cp @out@/lib/java/core-@version@.jar:@out@/lib/java/javase-@version@.jar "$@"
